primero = "Yerka"
segundo = "Freire"
nombre = primero +" "+ segundo
print(nombre)