#archivo_modo_a.py
with open('archivo_vacio.txt', 'a') as archivo:
    archivo.write('Hola')

