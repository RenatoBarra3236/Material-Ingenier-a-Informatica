# naturales.py
n = int(input('Ingrese un numero natural positivo: '))

i = 1

while i <= n:
    print(i)
    i = i + 1
    
    
    
    