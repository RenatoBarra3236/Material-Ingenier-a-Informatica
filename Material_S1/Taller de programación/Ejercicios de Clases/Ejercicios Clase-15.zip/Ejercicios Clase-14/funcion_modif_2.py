#funcion_modif_2.py
def inc(j):
    j = j + 1
    return j

i = 99
print(i)
inc(i)
print(i)

