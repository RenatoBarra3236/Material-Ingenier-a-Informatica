#lista_vacia.py
lista_1 =  []

lista_2 = list()

lista_1.append(10)
lista_1.append(15)
lista_1.append(20)

lista_2.append(1)
lista_2.append(5)
lista_2.append(7)

print('lista_1: ', lista_1)
print('lista_2: ', lista_2)

