#meses_1.py
meses = ['Enero','Febrero','Marzo','Abril','Mayo','Junio'
        ,'Julio','Agosto','Septiembre','Octubre','Noviembre'
        ,'Diciembre']

#Recorremos los elementos de la lista
for mes in meses:
    print(mes)

print(meses)



