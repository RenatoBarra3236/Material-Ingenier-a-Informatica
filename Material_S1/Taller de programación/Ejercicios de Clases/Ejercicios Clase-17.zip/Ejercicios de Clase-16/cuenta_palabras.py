#cuenta_palabras.py
def contador_palabras(frase):
    cuenta = dict()
    palabras = frase.split(" ")

    for i in palabras:
        if i in cuenta:
            cuenta[i] = cuenta[i] + 1
        else:
            cuenta[i] = 1
            
    return cuenta

texto = "Nunca te quejes de nadie, ni de nada, porque fundamentalmente tú has hecho lo que querías en tu vida."

print(contador_palabras(texto))

