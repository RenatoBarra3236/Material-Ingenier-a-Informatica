#max_min_key.py
lista_strings= ["ab", "abc", "abcde", "b"] 
string = 'ola'

# imprime el elemento de la lista con 
#el mayor número de caracteres
print(max(lista_strings, key = len)) 

# imprime el elemento de la lista con 
#el menor número de caracteres
print(min(lista_strings, key = len))


  