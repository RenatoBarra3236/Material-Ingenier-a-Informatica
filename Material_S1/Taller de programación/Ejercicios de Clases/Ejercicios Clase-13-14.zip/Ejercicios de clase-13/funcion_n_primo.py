#funcion_n_primo.py
def es_primo(n):
    if n < 2: return False
    i = 2
    while i*i <= n:
        if n % i == 0: return False
        i = i + 1
    return True

print('9 es primo?', es_primo(9))

