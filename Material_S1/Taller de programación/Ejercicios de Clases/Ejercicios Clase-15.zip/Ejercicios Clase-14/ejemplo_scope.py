#ejemplo_scope.py
x = 'hola'
y = 'gente'

def mymin(x, y):
    if x < y: return x
    else: return y

m = mymin(9,2)
print (m)

