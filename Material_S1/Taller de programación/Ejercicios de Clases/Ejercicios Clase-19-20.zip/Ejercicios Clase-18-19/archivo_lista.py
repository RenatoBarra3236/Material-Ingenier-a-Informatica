#archivo_lista.py
#Datos que guardaremos en un archivo
data = ['Línea 1', 'Línea 2', 'Línea 3', 'Línea 4', 'Línea 5']
archivo = open('archivo.txt', 'w')
for linea in data:
	archivo.write(linea)
	archivo.write('\n')
archivo.close()



