#modulo_math.py
from math import sqrt, radians, floor

n = int(input("Ingrese el número para obtener su raíz cuadrada: "))
print(sqrt(n))

angulo = int(input("Ingrese un ángulo en grados sexagesimales: "))
angulo_rad = radians(angulo)
print(angulo, "grados sexagesimales son equivalentes a: ",
      angulo_rad, " radianes") 

m = float(input("Ingrese un número decimal para aproximar hacia abajo: "))
m_aprox = floor(m) 
print(m_aprox)