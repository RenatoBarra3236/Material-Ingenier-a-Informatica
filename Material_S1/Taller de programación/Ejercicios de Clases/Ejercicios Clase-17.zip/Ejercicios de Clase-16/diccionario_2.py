#diccionario_2
emerg_dicc = {"Ambulancia": 131, "Bomberos": 132, "Carabineros": 133}
emerg_dicc["PDI"] = 134

print("El número telefónico de los Bomberos es ", emerg_dicc["Bomberos"]) 


