#n_impar_3.py
n = int(input('ingrese n: '))
for i in range(1, n, 2): #Sumar 1 a n
    print(i)
