#escribir_archivo.py
with open('nombre_archivo.extensión', 'w') as f:
    datos = 'Texto para escribir'
    f.write(datos)



    
    
    
