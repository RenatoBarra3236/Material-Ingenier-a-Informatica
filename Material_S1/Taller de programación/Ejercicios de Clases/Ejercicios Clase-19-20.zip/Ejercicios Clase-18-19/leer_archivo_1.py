#leer_archivo_1.py
# Abre el archivo
archivo = open('nombre_archivo.extensión', 'r')
datos = archivo.read()
print(datos)
# Cierra el archivo
archivo.close() 



