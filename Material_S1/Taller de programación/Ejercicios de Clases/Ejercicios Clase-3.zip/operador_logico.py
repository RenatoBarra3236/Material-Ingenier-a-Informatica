a = True
b = False
c = a or b
print("not a = ", not a)
print("a o b = ", a or b)
print("a y b = ", a and b)
print("c = ", c)