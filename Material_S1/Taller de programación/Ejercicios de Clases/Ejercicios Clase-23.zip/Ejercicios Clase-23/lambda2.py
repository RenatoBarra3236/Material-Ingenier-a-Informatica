#lambda2.py
#Ordena un diccionario según una llave específica
personas = [
    {'nombre': 'Juan', 'edad': 30},
    {'nombre': 'Ana', 'edad': 25},
    {'nombre': 'Pedro', 'edad': 35}]
personas_ordenadas = sorted(personas, key=lambda x: x['edad'])
print(personas_ordenadas)


