#importar_2.py
import math

print(math.sin(10))
print(math.cos(20))