#valores_diccionario.py
d = {"Python": 1991, "C": 1972, "Java": 1996}

for valor in d.values():
    print(valor)

