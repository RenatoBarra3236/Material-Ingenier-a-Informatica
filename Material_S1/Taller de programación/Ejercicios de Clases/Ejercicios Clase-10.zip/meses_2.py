#meses_2.py
meses = ['Enero','Febrero','Marzo','Abril','Mayo','Junio'
        ,'Julio','Agosto','Septiembre','Octubre','Noviembre'
        ,'Diciembre']

n = len(meses) # tamaño lista meses

#Recorremos la posiciones de los elementos de la lista, para luego acceder a ellos desde su posición
for i in range(n): 
    print(meses[i])

    #print('el valor de i en la iteración: ', i+1, 'es: ', i)
    
    #print('el elemento de la lista, en la posición: ', i, 'es: ',  meses[i])


