#multiplica.py
def multiplica(a, b):
    c = a * b
    print(c)

multiplica(2, 5)