string = input("ingrese una palabra o número: ")

for i in string:
    print(i)