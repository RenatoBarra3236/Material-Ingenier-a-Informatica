#n_impar_2.py
n = int(float(input('ingrese n: ')))
for i in range(n): #Sumar 1 a n
    if i % 2 == 1:
        print(i)
