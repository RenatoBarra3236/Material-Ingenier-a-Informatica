numero = int(input("Ingrese un numero: "))

i=1

contador = 0

while i <= numero:
    if i % 2 == 0:
        print(i, 'es par')
        contador = contador + 1
    i = i + 1

print('Numero de pares entre 1 y',  numero , 'es :', contador)



