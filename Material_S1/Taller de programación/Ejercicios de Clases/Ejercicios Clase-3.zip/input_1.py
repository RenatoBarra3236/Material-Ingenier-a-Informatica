nombre = input("Ingrese su nombre: ")
edad = input("Ingrese su edad: ")
print("Hola", nombre,"veo que tienes", edad, "años")

decenas = edad // 10
print("Y al menos tienes", decenas, "décadas")



