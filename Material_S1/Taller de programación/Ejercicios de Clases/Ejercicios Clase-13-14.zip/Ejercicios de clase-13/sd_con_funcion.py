#sd_con_funcion.py
from math import sqrt

def prom(lista):
    return sum(lista)/len(lista)

def desviacion(lista):
    p = prom(lista)
    d = 0
    for e in lista:
        d = d + (e - p)**2
    return sqrt(d / (len(lista)-1))

L = [67, 45, 84]
print(desviacion(L))


