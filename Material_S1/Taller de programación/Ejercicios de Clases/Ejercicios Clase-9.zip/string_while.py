string = input("ingrese una palabra o número: ")

i = 0
while i <= (len(string)-1):
    print(string[i])
    i = i + 1