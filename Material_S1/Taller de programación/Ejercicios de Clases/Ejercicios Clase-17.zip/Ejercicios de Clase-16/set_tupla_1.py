#set_tupla_1.py
A = {[1, 2, 3, 4], list(['a', 'b', 'c'])}
print('A:', A)
print('(1, 2, 3, 4) in A?:', (1, 2, 3, 4) in A)

