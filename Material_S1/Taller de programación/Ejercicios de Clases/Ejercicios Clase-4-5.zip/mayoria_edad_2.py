edad = int(input("Ingresa tu edad: "))

if edad > 18:
  print("Eres mayor de 18")
elif edad == 18:
  print("Tienes 18")
else:
  print("Eres menor de 18")