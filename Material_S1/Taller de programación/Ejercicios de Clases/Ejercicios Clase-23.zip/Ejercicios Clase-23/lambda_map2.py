#labda_map2.py
#Pone en mayúsculas los strings de una lista
palabras = ('hola', 'mundo', 'python')
resultados = map(str.upper, palabras)
print(list(resultados))  

