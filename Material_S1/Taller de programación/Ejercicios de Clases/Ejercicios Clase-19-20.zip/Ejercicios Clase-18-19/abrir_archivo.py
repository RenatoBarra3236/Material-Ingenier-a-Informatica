#Abrir_archivo.py
archivo = open("gini_by_country.csv","r")

for l in archivo:
    print(l)

archivo.close()

