#compresion3.py
palabras = ['hola', 'mundo', 'python']
palabras_mayus = [palabra.upper() for palabra in palabras]
print(palabras_mayus) 

