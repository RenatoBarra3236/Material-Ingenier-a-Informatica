#primera_funcion.py
def promedio(lista):
    s = 0
    for e in lista:
        s = s + e
    prom = s / len(lista)
    return prom

L = [1, 2, 3, 4]
print(promedio(L))



