#sd_sin_funcion.py
from math import sqrt
L = [67, 45, 84]
s = 0
for e in L:
    s = s + e
prom = s / len(L)

d = 0
for e in L:
    d = d + (e - prom)**2
sd = sqrt(d / (len(L)-1))
print(sd)

