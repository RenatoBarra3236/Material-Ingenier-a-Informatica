#matriz.py
def crear(m,n):
#retorna una de m x n ceros
    matriz = []
    for i in range(m):
        matriz.append([0]*n)
    return matriz

def asignar(matriz, i, j, v):
#asigna el valor v en la posición i,j
    matriz[i][j] = v

def imprimir(matriz):
#imprime una matriz, fila por fila
    for fila in matriz:
        print(fila)
        

