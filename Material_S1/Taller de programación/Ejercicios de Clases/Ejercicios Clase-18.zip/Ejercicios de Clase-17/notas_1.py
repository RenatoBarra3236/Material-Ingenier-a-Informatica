#notas_1.py
nombres       = ['Daniela', 'Esteban', 'Ricardo', 'Maite', 'Javiera']
notas_progra  = [4.5, 5.0, 6.1, 5.8, 6.8]
notas_calculo = [6.5, 4.3, 5.2, 6.7, 4.9]

def obtener_notas(estudiante, lista_nombres, lista_notas):
    nombre = lista_nombres.index(estudiante)
    nota = lista_notas[nombre]
    return nota

nota = obtener_notas('Ricardo', nombres, notas_progra)
print('Ricardo tiene un', nota, 'en el curso de Programación')


