# extras_pizza_3.py
num_beb = int(input('Cuantas bebidas de 1.5 L. ($1990 cada una) desea?: '))
num_pap = int(input('Cuantos paquetes de papas fritas ($1590 cada uno) desea?: '))
num_hel = int(input('Cuantos helados de L. ($2990) desea?: '))

if num_beb < 0 or num_pap < 0 or num_hel < 0:
    print('Error en algún número ingresado, intentelo otra vez')
else:
    total_extra = 1990*num_beb + 1590*num_pap + 2990*num_hel
    print('Total a pagar:', total_extra)
    


