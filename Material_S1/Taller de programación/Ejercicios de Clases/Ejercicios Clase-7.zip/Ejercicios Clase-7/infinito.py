x = 1
while True:
    print('Al infinito y mas alla! Ya vamos en :', x)
    x = x + 1
    

