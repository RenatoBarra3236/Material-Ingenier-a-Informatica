#leer_archivo_2.py
with open('nombre_archivo.extensión', 'r') as archivo:
    datos = archivo.read()
    print(datos)


        