#matriz_2.py
def crear(m,n):
#retorna una de m x n ceros
    matriz = []
    for i in range(m):
        matriz.append([0]*n)
    return matriz

def asignar(matriz, i, j, v):
#asigna el valor v en la posición i,j
    matriz[i][j] = v

def imprimir(matriz):
#imprime una matriz, fila por fila
    for fila in matriz:
        print(fila)
        
if __name__== "__main__":
    matriz_1 = crear(4,5)
    asignar(matriz_1, 0, 0, 5)
    asignar(matriz_1, 2, 2, 3)
    asignar(matriz_1, 3, 4, 7)
    imprimir(matriz_1)
    
    
    
    