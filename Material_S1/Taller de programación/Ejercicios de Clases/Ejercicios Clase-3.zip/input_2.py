primos = input('Cuántos primos tienes?')
primos_menores = input("Cuántos primos son menores que tú?")

num_primos = int(primos)
num_primos_menores = int(primos_menores)
porcentaje = num_primos_menores / num_primos * 100

print("El", porcentaje, "% de primos son menores que tú") 