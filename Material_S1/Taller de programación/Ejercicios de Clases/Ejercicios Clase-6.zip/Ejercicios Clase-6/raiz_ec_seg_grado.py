a = int(input("Ingrese el valor de a"))
b = int(input("Ingrese el valor de b"))
c = int(input("Ingrese el valor de c"))
x1 = (-b + ( b**2 - (4*a*c) ) ** (1/2) ) / (2*a)
x2 = (-b - ( b**2 - (4*a*c) ) ** (1/2) ) / (2*a)
x1_int = int(x1)
x2_int = int(x2)
print(x1, x2)

if x1 == x1_int:
    print("La solución", x1, "es un número entero")
else:
    print("La solción", x1, "es un decimal")
if x2 == x2_int:
    print("La solución", x2, "es un número entero")
else:
    print("La solción", x2, "es un decimal")
       
