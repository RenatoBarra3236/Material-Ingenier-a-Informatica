#modulo_random.py
from random import choice, randrange

pintas = ['Espada', 'Basto', 'Oro', 'Copa']
print(choice(pintas))

n = int(input("Ingrese un número entero positivo: "))
print(randrange(n)) 

