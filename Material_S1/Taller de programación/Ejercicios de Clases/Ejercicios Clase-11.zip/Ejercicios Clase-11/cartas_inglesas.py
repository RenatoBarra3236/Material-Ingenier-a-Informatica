#cartas_inglesas.py
from random import randrange

#print('número al azar entre 0 y 10:', randrange(0,11))

VALORES = ['2', '3', '4', '5', '6', '7', '8', '9', '10',
         'Jota', 'Reina', 'Rey', 'As']

TRAJES = ['Picas', 'Diamantes', 'Treboles', 'Corazones']

print('número al azar entre 0 y 2: ', randrange(0,3))

valor = randrange(0, len(VALORES))
print('Posición al azar en la lista valores', valor)

traje = randrange(0, len(TRAJES))
print('Posición al azar en la lista TRAJES', traje)

print(VALORES[valor],'de ', TRAJES[traje])

