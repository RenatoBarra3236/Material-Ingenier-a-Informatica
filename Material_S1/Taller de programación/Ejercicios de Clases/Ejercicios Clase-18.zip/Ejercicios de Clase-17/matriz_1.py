#matriz_1.py

filas = 3
columnas = 4

matriz = []

for i in range(filas):
    matriz.append([0]*columnas)

print(matriz)


