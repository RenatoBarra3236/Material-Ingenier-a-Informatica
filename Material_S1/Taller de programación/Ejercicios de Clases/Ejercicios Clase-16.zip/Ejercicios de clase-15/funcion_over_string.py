#funcion_over_string.py
string_de_prueba = "- - - programar es muy divertido - - -"

#Usando strip() para borrar todos los '-'
print (string_de_prueba.strip('- - -'))

# Usando lstrip() para borrar los '-' anteriores
print (string_de_prueba.lstrip('- - -'))

# Usando rstrip() para borrar los '-' posteriores
print (string_de_prueba.rstrip('- - -'))

#Usando replace() para reemplazar 'divertido' por 'genial'
print(string_de_prueba.replace('divertido', 'genial'))

#Usando split() para romper el string y guadar sus partes en una lista
print(string_de_prueba.split(' ', 7))


