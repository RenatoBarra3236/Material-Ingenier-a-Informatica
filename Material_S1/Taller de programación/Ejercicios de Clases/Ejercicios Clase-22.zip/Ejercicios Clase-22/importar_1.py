#importar_1.py
from math import sin, cos

print(sin(10))
print(cos(10))