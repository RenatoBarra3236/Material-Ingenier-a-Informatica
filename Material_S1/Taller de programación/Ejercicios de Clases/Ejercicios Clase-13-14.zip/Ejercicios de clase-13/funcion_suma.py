#funcion_suma.py
def suma(a, b):
    c = a + b
    return c

s = suma(2, 5)
print(s)

