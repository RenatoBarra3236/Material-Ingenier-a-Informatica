#actividad.py
f = open("2020-05-01-CasosConfirmados.csv", "r")

for l in f:
    print(l)
    
f.close()