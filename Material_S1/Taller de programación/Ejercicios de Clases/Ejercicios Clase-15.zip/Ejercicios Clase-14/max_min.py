#max_min.py
lista_strings= ["ab", "abc", "abd", "b"] 
string = 'abc'
  
# imprime el elemento de la lista con 
#el valor lexicográficamente más alto
print(max(lista_strings)) 
  
# imprime el elemento de la lista con 
#el valor lexicográficamente más bajo
print(min(lista_strings)) 
  
# imprime el caracter del string con 
#el valor lexicográficamente más alto
print(max(string)) 
  
# imprime el caracter del string con 
#el valor lexicográficamente más bajo
print(min(string)) 

