#lambda_map1.py
#Genera una lista con los cuadrados de otra lista
numeros = [1, 2, 3, 4, 5]
cuadrados = list(map(lambda x: x**2, numeros))
print(cuadrados) 


