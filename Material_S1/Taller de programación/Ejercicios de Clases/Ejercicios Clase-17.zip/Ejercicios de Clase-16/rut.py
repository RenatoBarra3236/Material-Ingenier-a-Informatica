rut = input("Ingrese su RUT, sin puntos y con guión: ")
rut = rut.upper()

rut_div = rut.split("-")
l0 = []
for i in rut_div[0]:
    l0.append(int(i))
l1 = list(reversed(l0))

l_prod = []
cont = 2
for i in l1:
    prod = i * cont
    l_prod.append(prod)
    if cont<7:
        cont = cont + 1
    else: cont = 2
suma = sum(l_prod)
res_div = suma%11
dig_verif = 11 - res_div

if dig_verif == 10:
    dig_verif = "K"
elif dig_verif == 11:
    dig_verif = "0"
if str(dig_verif)==rut_div[1]:
    print(True)
else: print(False)
