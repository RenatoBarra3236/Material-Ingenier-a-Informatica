#cartas.py
cartas = ['Diamante','Corazón','Pica','Trébol', 50]

print(cartas[2])

