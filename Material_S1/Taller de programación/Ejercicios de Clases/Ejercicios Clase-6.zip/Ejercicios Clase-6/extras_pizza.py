# extras_pizza.py
num_beb = input('Cuantas bebidas de 1.5 L. ($1990 cada una) desea?: ')
num_pap = input('Cuantos paquetes de papas fritas ($1590 cada uno) desea?: ')
num_hel = input('Cuantos helados de L. ($2990) desea?: ')

total_extra = 1990*num_beb + 1590*num_pap + 2990*num_hel

print('Total a pagar:', total_extra)

