#función_modif_3.py
def inc(j):
    j = j + 1
    return j

i = 99
print(i)
i = inc(i)
print(i)

