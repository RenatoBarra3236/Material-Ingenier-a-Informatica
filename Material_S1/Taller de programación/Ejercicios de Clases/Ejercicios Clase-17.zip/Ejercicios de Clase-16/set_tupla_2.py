#set_tupla_2.py
A = {(1, 2, 3, 4), tuple(['a', 'b', 'c'])}
print('A:', A)
print('(1, 2, 3, 4) in A?:', (1, 2, 3, 4) in A)

