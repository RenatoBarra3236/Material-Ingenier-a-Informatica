#funcion_modif_1.py
def inc(L):
    L.append(33)
    return

a = [1, 2]
print(a)
inc(a)
print(a)

