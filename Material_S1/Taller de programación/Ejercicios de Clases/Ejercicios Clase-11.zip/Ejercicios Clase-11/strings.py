#strings.py
s = "Hola mundo!"
print('el tamaño de s es: ', len(s))

# concatenar
s1 = 'Hola' + ' '
s2 = 'Chao'
s3 = s1 + s2
print(s3)

# acceso, la primera posición comienza en 0
print(s1[3]) # imprime el 4to elemento

# substring
s4 = s[1:7]
print('s[1:7] = ', s4)

# actualizar string: concatenar
print(s[1:])
nuevo = "Wow" + s[1:]
print(nuevo)

# actualizar string: reemplazar
nuevo2 = "chao{}".format(s[4:])
print(nuevo2)

