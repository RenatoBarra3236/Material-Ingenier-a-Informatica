s = input('ingrese un string: ')
print(s)
###########################################################################
print(len(s)) #Tamaño del string
###########################################################################
i = 2
ch = s[i]
print(ch) #caracter en la posición i
###########################################################################
b = s # aquí si funciona la copia!
print(b)
##########################################################################
#Compara dos strings
if s == 'gatito':
    print('s es igual a mensaje')
else:
    print('s es distinto a mensaje')
##########################################################################
#Concatena strings
c = s + ' más texto'
print(c)
##########################################################################
j = 4
caracteres = s[i : i+j ] #Extrae j carácteres a partir de la posición i
##########################################################################
n_entero = int(s) # Convertimos un string en entero
print(n_entero)
##########################################################################
i = 9543
numero = str(i)  # Convertimos un entero en string
##########################################################################
#Chequeamos si un substring está contenido en un string
mensaje = 'la udd la lleva'
if 'udd' in mensaje:
    print('todo bien!')
else:
    print('buuuu')
##########################################################################
#Concatenamos una lista cuyos elementos son strings    
L = [ 'uno',  'dos',  'tres' ]
s = ', '.join(L)
print(s) 
# imprime: 'uno,dos,tres'
