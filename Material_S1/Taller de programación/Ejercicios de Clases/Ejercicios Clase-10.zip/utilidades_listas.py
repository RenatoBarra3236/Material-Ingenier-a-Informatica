# lista con valores desde teclado
L = [] #lista vac��a
N=int(input('ingrese el n�mero de elementos de la lista L: '))
for i in range(N):
    v = input("Ingrese un elemento a la lista: ")
    L.append(v)

print('Imprimir elementos en lista', '\n')
# imprimir elementos en lista
for elemento in L:
    print(elemento)
 
print('Imprimir elementos en lista', '\n')
# imprimir elementos en lista (otra forma)
for i in range(N):
    print(L[i])
    

print('Maximo', '\n')

# encontrar el m�ximo
Lista = [0, 5, 3, 8, 999, -1000]
maximo = Lista[0]
for elem in Lista:
    if elem > maximo:
        maximo = elem
print("El maximo es:", maximo)

print('Minimo', '\n')

# encontrar el m�nimo
mini = L[0]
for elem in L:
    if elem < mini:
        mini = elem
print("El minimo es:",mini)

# promedio
suma = 0.0
for elem in L:
    suma = suma + elem
prom = suma/len(N)
print('El promedio de la lista L es: ', prom)

# copiar lista
L2 = []
for elem in L:
    L2.append(elem)

# invertir elementos de la lista
N = len(L)
for i in range(N):
    temp = L[i]
    L[i] = L[N-i-1]
    L[N-i-1] = temp

# insertar elemento al final
L.append(33)
