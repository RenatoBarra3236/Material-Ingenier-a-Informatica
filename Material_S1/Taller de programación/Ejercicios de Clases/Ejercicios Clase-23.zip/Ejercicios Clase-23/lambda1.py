#lambda1.py
#Función que suma (o concatena) dos variables
suma = lambda x, y: x + y
print(suma(3, 5))  

