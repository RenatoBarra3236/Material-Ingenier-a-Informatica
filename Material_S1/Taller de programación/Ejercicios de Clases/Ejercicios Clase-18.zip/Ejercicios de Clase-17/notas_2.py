#notas_2.py
notas = {'Daniela' : [4.5, 6.5, 7.0] 
         ,'Esteban': [5.0, 4.3, 2.0]
         ,'Ricardo': [6.1, 5.2, 4.3]
         ,'Maite'  : [5.8, 6.7, 3.8]
         ,'Javiera': [6.8, 4.9, 3.0]
         , 100 : 'hola'}

def obtener_notas(estudiante, dict_notas):
    nota_progra = dict_notas[estudiante][0]
    nota_calculo = dict_notas[estudiante][1]
    return nota_progra, nota_calculo

nota_pro, nota_cal = obtener_notas('Ricardo', notas)
print('Ricardo tiene un', nota_pro, 'en Programación, y un', nota_cal, 'en Cálculo')



