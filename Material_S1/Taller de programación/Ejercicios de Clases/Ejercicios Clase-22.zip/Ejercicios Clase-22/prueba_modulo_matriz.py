#prueba_modulo_matriz.py
import matriz_2

m = matriz_2.crear(3,3)
matriz_2.asignar(m, 0, 1, 9)
matriz_2.asignar(m, 2, 2, 3)
matriz_2.asignar(m, 1, 2, 1)
matriz_2.imprimir(m)