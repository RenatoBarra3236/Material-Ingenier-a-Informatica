#diccionario_1
emerg_dicc = dict()
emerg_dicc["Ambulancia"] = 131
emerg_dicc["Bomberos"] = 132
emerg_dicc["Carabineros"] = 133
emerg_dicc["PDI"] = 134

print("El número telefónico de la PDI es ", emerg_dicc["PDI"])


