#alias_1.py
L = [1, 2, 3]
C = L #.copy()

L[0] = 99

print(L)
print(C)

